package com.company;

public enum SuperAbility {
    BERSERK,
    SUPER_HIT

}
