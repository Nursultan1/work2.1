package com.company;

public class Called extends Warrior  {
    public Called(int damage, int health, String name,SuperAbility superAbility) {
        super(damage, health,name,superAbility);
    }



}
